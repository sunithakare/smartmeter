package com.envision.login.database.projections;



public interface SystemRoleListResponse {
	String getRoleName();
	String getRoleDesc();
	String getRoleType();
	
}
