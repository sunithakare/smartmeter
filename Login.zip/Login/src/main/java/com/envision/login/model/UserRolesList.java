package com.envision.login.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserRolesList {
	   	String roleName;
	    String roleDesc;
	    String roleType;
}
